window.TEAM_ACTIVITY_CONFIG = {
    proxyUrl: "http://127.0.0.1:9000",
    activeWindowMinutes: 90,
    recentWindowMinutes: 240,
    longEntryHours: 8,
    requestTimeoutMs: 12000,
    team: [
        { id: 14, name: "Arshana" },
        { id: 142, name: "Chathumini" },
        { id: 141, name: "Himesh" },
        { id: 11, name: "Kavin" },
        { id: 20, name: "Navod" }
    ]
};
